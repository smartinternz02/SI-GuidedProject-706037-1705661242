<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Shopping List</name>
   <tag></tag>
   <elementGuidId>a60cf46d-a3f1-48a0-907c-ed4e17963d0c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='huc-list-link']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#huc-list-link > span.a-size-medium-plus.huc-atwl-header-main</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>06b807c0-9c15-4be2-a096-c3a5a5f4f9c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-medium-plus huc-atwl-header-main</value>
      <webElementGuid>1d50f29f-a99a-4955-980b-fbfeabdbe822</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Shopping List</value>
      <webElementGuid>10569255-85ff-4419-b2d7-e1333da6a52c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;huc-list-link&quot;)/span[@class=&quot;a-size-medium-plus huc-atwl-header-main&quot;]</value>
      <webElementGuid>9dc55c43-6057-44df-9b3b-ca7ea14d452b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='huc-list-link']/span</value>
      <webElementGuid>e26861ac-fc20-4994-9147-e37d2cb2df7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Shopping List' or . = 'Shopping List')]</value>
      <webElementGuid>83249dc6-b323-47b3-8150-103418949c5f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
