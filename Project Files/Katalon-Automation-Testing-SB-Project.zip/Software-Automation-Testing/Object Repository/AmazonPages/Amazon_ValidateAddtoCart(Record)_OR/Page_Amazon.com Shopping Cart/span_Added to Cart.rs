<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Added to Cart</name>
   <tag></tag>
   <elementGuidId>87550314-e732-4964-9d47-627115267945</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-size-medium-plus.a-color-base.sw-atc-text.a-text-bold</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c284a92b-240f-42e1-925f-b67fc906e395</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-medium-plus a-color-base sw-atc-text a-text-bold</value>
      <webElementGuid>fa6efd24-113d-4721-961a-8fbecced048d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            Added to Cart
        
    </value>
      <webElementGuid>63bc653e-ee7f-4642-8484-f6d5bd2ca6c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;NATC_SMART_WAGON_CONF_MSG_SUCCESS&quot;)/span[@class=&quot;a-size-medium-plus a-color-base sw-atc-text a-text-bold&quot;]</value>
      <webElementGuid>4deffb43-226c-4b57-b013-626cfa74897a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']/span</value>
      <webElementGuid>79b1c0e0-ccb8-4d32-ac0a-0dcce9d9a9b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div[2]/div/div/div/div/span</value>
      <webElementGuid>2a4c9854-e917-4355-8e97-608a567caa80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        
            Added to Cart
        
    ' or . = '
        
            Added to Cart
        
    ')]</value>
      <webElementGuid>2f25fdbc-50c1-4af3-a59b-395262de1dd8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
