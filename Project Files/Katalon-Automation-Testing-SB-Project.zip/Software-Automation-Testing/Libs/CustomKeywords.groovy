
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String



def static "com.qa.test.customFunctions.CheckDropDownListElementExist"(
    	TestObject object	
     , 	String option	) {
    (new com.qa.test.customFunctions()).CheckDropDownListElementExist(
        	object
         , 	option)
}


def static "com.qa.test.customFunctions.GetDropDownListElementCount"(
    	TestObject object	) {
    (new com.qa.test.customFunctions()).GetDropDownListElementCount(
        	object)
}
